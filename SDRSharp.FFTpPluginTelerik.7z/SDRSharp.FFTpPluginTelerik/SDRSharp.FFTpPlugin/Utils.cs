﻿using System.Reflection;

namespace SDRSharp.FFTpPlugin
{
    class Utils
    {
        public static string Version()
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            return assembly.GetName().Version.ToString();
        }
    }
}
